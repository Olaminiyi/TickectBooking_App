/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uscticketbookingapp;

import java.util.Scanner;

/**
 *
 * @author niyi
 */
public class UscTicketBookingApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        BookingController book = new BookingController();
        GenerateReport rpt = new GenerateReport();
        rpt.GenerateStudentsPerClassWithRating();
        rpt.GeneratGroupExercisesWithHighestIncome();
       // Scanner scanner = new Scanner(System.in);
      //  System.out.println("Please enter your name");
      //  System.out.println("Please enter your name");
        // book.bookAClass(s,"");
    }

}
