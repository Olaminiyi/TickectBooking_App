/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uscticketbookingapp.enums;

import uscticketbookingapp.models.ExerciseClass;
import java.util.ArrayList;

/**
 *
 * @author niyi
 */
public enum ExerciseDay {
    SATURDAY,
    SUNDAY
//    String dayType;
//    ArrayList<ExerciseClass> exCourses;
//    static final int MAX_COURSE_IN_A_DAY = 3;
//    
//    public ExDay(String dayType){
//        this.dayType = dayType;
//        exCourses = new ArrayList<ExerciseClass>();
//    }
//    
//    public boolean addNewCourse(ExerciseClass c){
//    if(this.exCourses.size()< ExDay.MAX_COURSE_IN_A_DAY){
//        this.exCourses.add((c));
//        return true;
//    }
//    else
//        return false;
//    }
}
