/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uscticketbookingapp;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import uscticketbookingapp.data.StudentExerciseClassBookingData;
import uscticketbookingapp.data.StudentExerciseClassData;
import uscticketbookingapp.models.ExerciseStudentCountRatingReport;
import uscticketbookingapp.models.Student;
import uscticketbookingapp.models.StudentExerciseClass;
import uscticketbookingapp.models.StudentExerciseClassBooking;
import uscticketbookingapp.models.TotalIncomePerExerciseReport;

/**
 *
 * @author niyi
 */
public class GenerateReport {

    float totalRating = 0;

    private static <T> Predicate<T> distinctByKey(Function<? super T, ?> keyExtractor) {
        Map<Object, Boolean> seen = new ConcurrentHashMap<>();
        return t -> seen.putIfAbsent(keyExtractor.apply(t), Boolean.TRUE) == null;
    }

    public List<ExerciseStudentCountRatingReport> GenerateStudentsPerClassWithRating() {

        List<ExerciseStudentCountRatingReport> report = new ArrayList<ExerciseStudentCountRatingReport>();
        try {
            //get report for total students per class per day and average rating
            //get exercise days
            List<StudentExerciseClass> exerciseClasses = StudentExerciseClassData.getStudentExerciseClassData();

            final List<String> dates = new ArrayList<String>();
            for (int i = 0; i < exerciseClasses.size(); i++) {
                String exerciseClassName = exerciseClasses.get(i).getExerciseClassTable().getExerciseClass().getClassName();
                Date date = new SimpleDateFormat("yyyy-MM-dd").parse(exerciseClasses.get(i).getExerciseClassTable().getDate());
                String dateonly = new SimpleDateFormat("yyyy-MM-dd").format(date);
                if (!dates.contains(dateonly)) {
                    dates.add(dateonly);
                }
            }

            //get distinct exercise classes
            List<StudentExerciseClass> distinctExercises = exerciseClasses.stream().filter(distinctByKey(b -> b.getExerciseClassTable().getExerciseClass().getClassName())).collect(Collectors.toList());
            //get students on each day with rating
            distinctExercises.forEach(exclass -> {
                ExerciseStudentCountRatingReport rpt = new ExerciseStudentCountRatingReport();
                rpt.setExerciseClass(exclass.getExerciseClassTable().getExerciseClass().getClassName());

                dates.forEach(date -> {
                    try {
                        int studentCount = 0;
                        rpt.setDate(date);
                        totalRating = 0;
                        List<StudentExerciseClass> exercisesPerDay = exerciseClasses
                                .stream()
                                .filter(r -> {
                                    Date dt = null;
                                    try {
                                        dt = new SimpleDateFormat("yyyy-MM-dd").parse(r.getExerciseClassTable().getDate());
                                    } catch (ParseException ex) {
                                        Logger.getLogger(GenerateReport.class.getName()).log(Level.SEVERE, null, ex);
                                    }
                                    String dateonly = new SimpleDateFormat("yyyy-MM-dd").format(dt);
                                    return dateonly.equals(date);
                                })
                                .collect(Collectors.toList());
                        //calculate average
                        studentCount = exercisesPerDay.size();
                        exercisesPerDay.forEach(e -> {
                            totalRating = totalRating + e.getRating();
                        });
                        rpt.setAverageRating((totalRating / studentCount));
                        rpt.setTotalStudents(studentCount);
                        report.add(rpt);
                        //set date/count/total ratings
                    } catch (Exception ex) {
                        Logger.getLogger(GenerateReport.class.getName()).log(Level.SEVERE, null, ex);
                    }
                });
            });
            System.out.println("LIST OF EXERCISE DATE COUNT AND AVERAGE RATING (ExerciseClass,TotalSTudents,Date,Average Rating) ");
            report.forEach(r -> {
                System.out.println(" " + r.getExerciseClass() + " - " + r.getTotalStudents() + " - " + r.getDate() + " - " + r.getAverageRating());
            });
            return report;
            //calculate average rating for each day
        } catch (Exception ex) {
            Logger.getLogger(GenerateReport.class.getName()).log(Level.SEVERE, null, ex);
        }
        return report;
    }

    int exerciseCount = 0;
    float totalIncomePerExercise = 0;

    public List<TotalIncomePerExerciseReport> GeneratGroupExercisesWithHighestIncome() {
        List<TotalIncomePerExerciseReport> report = new ArrayList<TotalIncomePerExerciseReport>();
        exerciseCount = 0;
        totalIncomePerExercise = 0;
        List<StudentExerciseClassBooking> allBookings = StudentExerciseClassBookingData.getStudentExerciseClassBooking();
        //get total income per exercise

        //get distinct exercise classes
        List<StudentExerciseClassBooking> distinctExercises = StudentExerciseClassBookingData
                .getStudentExerciseClassBooking()
                .stream()
                .filter(distinctByKey(c -> c.getExclassTimetable().getExerciseClass().getClassName()))
                .collect(Collectors.toList());
        distinctExercises.forEach(exclass -> {
            String exerciseName = exclass.getExclassTimetable().getExerciseClass().getClassName();
            TotalIncomePerExerciseReport rpt = new TotalIncomePerExerciseReport();
            rpt.setExerciseClass(exerciseName);
            allBookings.forEach(f -> {
                if (exerciseName.equals(f.getExclassTimetable().getExerciseClass().getClassName())) {
                    exerciseCount = exerciseCount + 1;
                    float paid = f.getExclassTimetable().getExerciseClass().getPrice();
                    totalIncomePerExercise = totalIncomePerExercise + paid;
                }
            });
            rpt.setTotalIncome(totalIncomePerExercise);
            report.add(rpt);
        });
        //sort in desc
        List<TotalIncomePerExerciseReport> sortedList = report.stream()
                .sorted((o1, o2) -> Float.compare(o2.getTotalIncome(), o1.getTotalIncome()))
                .collect(Collectors.toList());

        System.out.println("LIST OF EXERCISE WITH HIGHEST INCOME DESC ");
        sortedList.forEach(r -> {
            System.out.println(" " + r.getExerciseClass() + " - " + r.getTotalIncome());
        });

        return sortedList;
        //sort in descending order to get the one with highest income
    }

}
