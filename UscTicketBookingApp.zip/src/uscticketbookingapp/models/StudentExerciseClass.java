/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uscticketbookingapp.models;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author niyi
 */
public class StudentExerciseClass {

    /**
     * @return the rating
     */
    public int getRating() {
        return rating;
    }

    /**
     * @param rating the rating to set
     */
    public void setRating(int rating) {
        this.rating = rating;
    }

    /**
     * @return the ratingReview
     */
    public String getRatingReview() {
        return ratingReview;
    }

    /**
     * @param ratingReview the ratingReview to set
     */
    public void setRatingReview(String ratingReview) {
        this.ratingReview = ratingReview;
    }
    private int Id;
    private ExerciseClassesTimetable exerciseClassTable;    
    private Student student;
    private int rating;
    private String ratingReview;
    
    public StudentExerciseClass(int Id, ExerciseClassesTimetable exerciseClassTable, Student student, int rating, String ratingReview) {
        
        setExerciseClassTable(exerciseClassTable);
        setStudents(student);
        setId(Id);
        setRating(rating);
        setRatingReview(ratingReview);
    }

    /**
     * @return the exerciseClassTable
     */
    public ExerciseClassesTimetable getExerciseClassTable() {
        return exerciseClassTable;
    }

    /**
     * @param exerciseClassTable the exerciseClassTable to set
     */
    public void setExerciseClassTable(ExerciseClassesTimetable exerciseClassTable) {
        this.exerciseClassTable = exerciseClassTable;
    }

    /**
     * @return the students
     */
    public Student getStudents() {
        return student;
    }

    /**
     * @param students the students to set
     */
    public void setStudents(Student student) {
        this.student = student;
    }

    /**
     * @return the Id
     */
    public int getId() {
        return Id;
    }

    /**
     * @param Id the Id to set
     */
    public void setId(int Id) {
        this.Id = Id;
    }
    
}
