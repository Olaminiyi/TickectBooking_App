/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uscticketbookingapp.data;

import java.util.ArrayList;
import java.util.List;
import uscticketbookingapp.models.ExerciseClass;
import uscticketbookingapp.models.ExerciseClassesTimetable;
import uscticketbookingapp.models.Student;
import uscticketbookingapp.models.StudentExerciseClass;

/**
 *
 * @author niyi
 */
public class StudentExerciseClassData {

    public static List<StudentExerciseClass> getStudentExerciseClassData() {
        List<StudentExerciseClass> studentExerciseClass = new ArrayList<StudentExerciseClass>();

        studentExerciseClass.add(new StudentExerciseClass(1, ExerciseClassesTimetableData.getExerciseClassesTimeTable().get(0), StudentData.getStudents().get(0), 3, "great teacher"));
        studentExerciseClass.add(new StudentExerciseClass(2, ExerciseClassesTimetableData.getExerciseClassesTimeTable().get(0), StudentData.getStudents().get(1), 4, "Super interesting"));

        studentExerciseClass.add(new StudentExerciseClass(3, ExerciseClassesTimetableData.getExerciseClassesTimeTable().get(1), StudentData.getStudents().get(2), 2, "too intense"));
        studentExerciseClass.add(new StudentExerciseClass(4, ExerciseClassesTimetableData.getExerciseClassesTimeTable().get(1), StudentData.getStudents().get(3), 5, "perfect for me"));

        return studentExerciseClass;
    }
}
