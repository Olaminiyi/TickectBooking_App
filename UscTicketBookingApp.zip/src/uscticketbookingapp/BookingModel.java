/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uscticketbookingapp;
//
/**
 *
 * @author niyi
 */
public class BookingModel {
    
    static int satDayLog[][] = new int[3][4];
    static int sunDayLog[][] = new int [3][4];
    
    
      
    }

